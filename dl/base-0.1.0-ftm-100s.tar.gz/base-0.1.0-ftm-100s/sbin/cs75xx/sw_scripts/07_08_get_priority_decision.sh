#!/bin/sh
sw_cfg -c RTK_QOS_PRI_SEL_GET -s
sw_cfg -c RTK_QOS_PRI_SEL_GET -e

