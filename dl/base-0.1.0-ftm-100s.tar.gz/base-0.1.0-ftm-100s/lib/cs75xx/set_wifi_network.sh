#!/bin/sh
pci=$1
WFO_Enable=$2

if [ $pci0 -eq 0 ]; then
     ##Atheros  11ac
     cd /rboot/wfo_atheros_11AC
     if [ "$WFO_Enable" == "1" ]; then
       ./wfo_start.sh  
     elif [ "$WFO_Enable" == "14" ]; then
       /rboot/rboot ar988x_pe0.bin /rboot/ipsec/ipsec_pe1.bin
       #/rboot/rboot ar988x_pe0.bin

       sleep 2
       echo "enabling 11AC WFO..."
       echo 1 > /proc/driver/cs752x/wfo/wifi_offload_enable
       sh ath_11ac_ap.sh $pci 2
     else
       ./ath_11ac_ap.sh $pci
        
     fi     
     exit 0
fi

if [ $pci0 -eq 1 ]; then
     ##Atheros  11n
     cd /rboot/wfo_atheros_11AC
     if [ "$WFO_Enable" == "1" ]; then
       	/rboot/rboot ar988x_pe0.bin ar9580_pe1.bin 
	sleep 2
	echo "enabling 11n WFO..."
	echo 1 > /proc/driver/cs752x/wfo/wifi_offload_enable 
	./ath_11n_ap.sh $pci 1
     else
       ./ath_11n_ap.sh $pci
     fi     
     exit 0
fi
