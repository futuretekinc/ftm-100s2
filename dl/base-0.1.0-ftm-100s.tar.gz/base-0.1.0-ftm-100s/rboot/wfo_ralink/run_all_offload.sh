./moca.sh
sleep 40
./wfo_start.sh

