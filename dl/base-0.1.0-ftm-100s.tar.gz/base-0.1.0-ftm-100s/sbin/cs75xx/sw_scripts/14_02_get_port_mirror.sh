#!/bin/sh
sw_cfg -c RTK_MIRROR_PORT_BASED_GET -s
sw_cfg -c RTK_MIRROR_PORT_BASED_GET -e

